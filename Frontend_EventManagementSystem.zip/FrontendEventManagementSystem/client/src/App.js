// src/App.js
import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import EventList from "./components/EventList";
import CreateEventForm from "./components/CreateEventForm";
import UpdateEventForm from "./components/UpdateEventForm";
import DeleteEvent from "./components/DeleteEvent";
const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<EventList />} />
        <Route path="/create" element={<CreateEventForm />} />
        <Route path="/update" element={<UpdateEventForm />} />
        <Route path="/delete/*" element={<DeleteEvent />} />
      </Routes>
    </Router>
  );
};

export default App;
