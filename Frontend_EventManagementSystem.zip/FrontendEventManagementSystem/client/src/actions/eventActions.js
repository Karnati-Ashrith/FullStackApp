// src/actions/eventActions.js
import api from "../services/api";
import {
  fetchEventsRequest,
  fetchEventsSuccess,
  fetchEventsFailure,
  updateEventSuccess,
  deleteEventSuccess, // Import the new action creator
} from "../reducers/eventReducer";

export const fetchEvents = () => async (dispatch) => {
  dispatch(fetchEventsRequest());
  try {
    const response = await api.get("/");
    dispatch(fetchEventsSuccess(response.data));
  } catch (error) {
    dispatch(fetchEventsFailure(error.message));
  }
};
// Create an event
export const createEvent = (event) => async (dispatch) => {
  try {
    const response = await api.post("/", event);
    dispatch({ type: "CREATE_EVENT_SUCCESS", payload: response.data });
  } catch (error) {
    dispatch({ type: "CREATE_EVENT_FAILURE", payload: error.message });
  }
};
// Fetch a single event by ID
export const fetchEventById = (id) => async (dispatch) => {
  try {
    const response = await api.get(`/${id}`);
    return response.data; // Return the event data
  } catch (error) {
    dispatch(fetchEventsFailure(error.message));
  }
};

// Update an event
export const updateEvent = (id, updatedEvent) => async (dispatch) => {
  try {
    const response = await api.put(`/${id}`, updatedEvent);
    dispatch(updateEventSuccess(response.data));
    return response.data; // Return the updated event data
  } catch (error) {
    dispatch(fetchEventsFailure(error.message));
  }
};
// Delete an event
export const deleteEvent = (id) => async (dispatch) => {
  try {
    await api.delete(`/${id}`);
    dispatch(deleteEventSuccess(id)); // Dispatch the delete success action
  } catch (error) {
    dispatch(fetchEventsFailure(error.message));
  }
};
