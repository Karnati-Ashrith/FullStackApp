// src/components/DeleteEvent.js
import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useSearchParams, useNavigate } from "react-router-dom";
import { deleteEvent, fetchEventById } from "../actions/eventActions";

const DeleteEvent = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const eventId = searchParams.get("id");

  const { events } = useSelector((state) => state.events);
  const event = events.find((event) => event.id === parseInt(eventId));

  const handleDelete = () => {
    dispatch(deleteEvent(eventId)).then(() => {
      navigate("/");
    });
  };

  return (
    <div style={styles.container}>
      <h2>Delete Event</h2>
      {event ? (
        <div>
          <p>Are you sure you want to delete the following event?</p>
          <h3>{event.name}</h3>
          <p>{event.description}</p>
          <p>{event.location}</p>
          <p>{event.date}</p>
          <button onClick={handleDelete} style={styles.button}>
            Delete Event
          </button>
        </div>
      ) : (
        <p>Event not found.</p>
      )}
    </div>
  );
};

export default DeleteEvent;

// CSS styles
const styles = {
  container: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    height: "100vh",
    textAlign: "center",
  },
  button: {
    padding: "10px 20px",
    backgroundColor: "#dc3545",
    color: "#fff",
    border: "none",
    borderRadius: "5px",
    cursor: "pointer",
  },
};
