//src/components/UpdateEventForm.js
import React, { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useLocation, useNavigate } from "react-router-dom";
import { updateEvent, fetchEventById } from "../actions/eventActions";

const UpdateEventForm = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const location = useLocation();
  const eventId = new URLSearchParams(location.search).get("id");

  const [event, setEvent] = useState({
    name: "",
    date: "",
    location: "",
    description: "",
  });

  useEffect(() => {
    if (eventId) {
      dispatch(fetchEventById(eventId)).then((response) => {
        if (response) {
          setEvent(response);
        }
      });
    }
  }, [eventId, dispatch]);

  const handleChange = (e) => {
    setEvent({ ...event, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    dispatch(updateEvent(eventId, event)).then(() => {
      navigate("/");
    });
  };

  return (
    <div style={styles.container}>
      <h2>Update Event</h2>
      <form onSubmit={handleSubmit} style={styles.form}>
        <input
          type="text"
          name="name"
          placeholder="Event Name"
          value={event.name}
          onChange={handleChange}
          style={styles.input}
        />
        <br />
        <input
          type="datetime-local"
          name="date"
          value={event.date}
          onChange={handleChange}
          style={styles.input}
        />
        <br />
        <input
          type="text"
          name="location"
          placeholder="Location"
          value={event.location}
          onChange={handleChange}
          style={styles.input}
        />
        <br />
        <textarea
          name="description"
          placeholder="Description"
          value={event.description}
          onChange={handleChange}
          style={styles.textarea}
        />
        <br />
        <button type="submit" style={styles.button}>
          Update Event
        </button>
      </form>
    </div>
  );
};

export default UpdateEventForm;

// CSS styles
const styles = {
  container: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    height: "100vh",
    textAlign: "center",
  },
  form: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    width: "300px",
  },
  input: {
    width: "100%",
    padding: "10px",
    margin: "10px 0",
    borderRadius: "5px",
    border: "1px solid #ccc",
  },
  textarea: {
    width: "100%",
    padding: "10px",
    margin: "10px 0",
    borderRadius: "5px",
    border: "1px solid #ccc",
    resize: "vertical",
  },
  button: {
    padding: "10px 20px",
    backgroundColor: "#007bff",
    color: "#fff",
    border: "none",
    borderRadius: "5px",
    cursor: "pointer",
  },
};
