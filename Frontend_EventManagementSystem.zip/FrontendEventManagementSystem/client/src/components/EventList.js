// src/components/EventList.js
import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { fetchEvents } from "../actions/eventActions";

const EventList = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { events, loading, error } = useSelector((state) => state.events);

  useEffect(() => {
    dispatch(fetchEvents());
  }, [dispatch]);

  if (loading) return <p>Loading...</p>;
  if (error) return <p>Error: {error}</p>;

  // Function to handle navigation
  const handleNavigate = (path, id) => {
    navigate(`${path}?id=${id}`); // Navigate to the specified path with the event ID
  };

  // Button styles
  const buttonStyles = {
    margin: "5px",
    padding: "5px 10px",
    backgroundColor: "#007bff",
    color: "#fff",
    border: "none",
    borderRadius: "5px",
    cursor: "pointer",
  };

  return (
    <div style={styles.container}>
      {/* Header Section */}
      <h1 style={styles.systemTitle} align="center">
        Welcome to Event Management System
      </h1>
      <div style={styles.header}>
        <div style={styles.listHeader}>
          <h1>List of Events</h1>
          {/* New Event Button */}
          <button
            onClick={() => navigate("/create")}
            style={{ ...buttonStyles, backgroundColor: "#28a745" }} // Green color for New Event button
          >
            New Event
          </button>
        </div>
      </div>

      {/* List of Events */}
      <ul>
        {events.map((event) => (
          <li key={event.id}>
            <h2>{event.name}</h2>
            <p>{event.description}</p>
            <p>{event.location}</p>
            <p>{event.date}</p>
            <button
              onClick={() => handleNavigate("/update", event.id)}
              style={buttonStyles} // Apply styles to Edit button
            >
              Edit
            </button>{" "}
            <button
              onClick={() => handleNavigate("/delete", event.id)}
              style={{ ...buttonStyles, backgroundColor: "#dc3545" }} // Apply styles to Delete button with red background
            >
              Delete
            </button>{" "}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default EventList;

// CSS styles
const styles = {
  container: {
    padding: "20px",
  },
  header: {
    display: "flex",
    flexDirection: "column",
    alignItems: "flex-start",
    marginBottom: "15px",
  },
  systemTitle: {
    fontSize: "38px",
    fontWeight: "bold",

    marginBottom: "10px",
  },
  listHeader: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    width: "100%",
  },
};
