// // src/components/CreateEventForm.js
import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { createEvent } from "../actions/eventActions";

const CreateEventForm = () => {
  const [event, setEvent] = useState({
    name: "",
    date: "",
    location: "",
    description: "",
  });

  const dispatch = useDispatch();

  const handleChange = (e) => {
    setEvent({ ...event, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    dispatch(createEvent(event)).then(() => {
      setEvent({
        name: "",
        date: "",
        location: "",
        description: "",
      });
    });
  };

  return (
    <div style={styles.container}>
      <h2>Create a New Event</h2>
      <form onSubmit={handleSubmit} style={styles.form}>
        <input
          type="text"
          name="name"
          placeholder="Event Name"
          value={event.name}
          onChange={handleChange}
          style={styles.input}
        />
        <br />
        <input
          type="datetime-local"
          name="date"
          value={event.date}
          onChange={handleChange}
          style={styles.input}
        />
        <br />
        <input
          type="text"
          name="location"
          placeholder="Location"
          value={event.location}
          onChange={handleChange}
          style={styles.input}
        />
        <br />
        <textarea
          name="description"
          placeholder="Description"
          value={event.description}
          onChange={handleChange}
          style={styles.textarea}
        />
        <br />
        <button type="submit" style={styles.button}>
          Create Event
        </button>
      </form>
    </div>
  );
};

export default CreateEventForm;

// CSS styles
const styles = {
  container: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    height: "100vh",
    textAlign: "center",
  },
  form: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    width: "300px",
  },
  input: {
    width: "100%",
    padding: "10px",
    margin: "10px 0",
    borderRadius: "5px",
    border: "1px solid #ccc",
  },
  textarea: {
    width: "100%",
    padding: "10px",
    margin: "10px 0",
    borderRadius: "5px",
    border: "1px solid #ccc",
    resize: "vertical",
  },
  button: {
    padding: "10px 20px",
    backgroundColor: "#007bff",
    color: "#fff",
    border: "none",
    borderRadius: "5px",
    cursor: "pointer",
  },
};
