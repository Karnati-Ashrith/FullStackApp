// // src/reducers/eventReducer.js
const initialState = {
  events: [],
  loading: false,
  error: null,
};

const eventReducer = (state = initialState, action) => {
  switch (action.type) {
    case "FETCH_EVENTS_REQUEST":
      return { ...state, loading: true };
    case "FETCH_EVENTS_SUCCESS":
      return { ...state, loading: false, events: action.payload };
    case "FETCH_EVENTS_FAILURE":
      return { ...state, loading: false, error: action.payload };
    case "UPDATE_EVENT_SUCCESS":
      const updatedEvent = action.payload;
      return {
        ...state,
        events: state.events.map((event) =>
          event.id === updatedEvent.id ? updatedEvent : event
        ),
      };
    case "DELETE_EVENT_SUCCESS":
      const deletedEventId = action.payload;
      return {
        ...state,
        events: state.events.filter((event) => event.id !== deletedEventId),
      };
    default:
      return state;
  }
};

export const fetchEventsRequest = () => ({ type: "FETCH_EVENTS_REQUEST" });
export const fetchEventsSuccess = (payload) => ({
  type: "FETCH_EVENTS_SUCCESS",
  payload,
});
export const fetchEventsFailure = (payload) => ({
  type: "FETCH_EVENTS_FAILURE",
  payload,
});
export const updateEventSuccess = (payload) => ({
  type: "UPDATE_EVENT_SUCCESS",
  payload,
});
export const deleteEventSuccess = (payload) => ({
  type: "DELETE_EVENT_SUCCESS",
  payload,
});

export default eventReducer;
