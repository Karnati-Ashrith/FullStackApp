// src/services/api.js
import axios from "axios";

const api = axios.create({
  baseURL: "https://localhost:7043/api/Event", // Backend URL
});

export default api;
